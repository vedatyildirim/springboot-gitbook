package com.vedatyildirim.restfulcrudexample.service.impl;

import com.vedatyildirim.restfulcrudexample.domain.Author;
import com.vedatyildirim.restfulcrudexample.dto.AuthorDto;
import com.vedatyildirim.restfulcrudexample.repository.AuthorRepository;
import com.vedatyildirim.restfulcrudexample.service.AuthorService;
import com.vedatyildirim.restfulcrudexample.util.TPage;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.List;

@Service
@Transactional
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private final AuthorRepository authorRepository;

    @Autowired
    private final ModelMapper modelMapper;

    public AuthorServiceImpl(AuthorRepository authorRepository, ModelMapper modelMapper) {
        this.authorRepository = authorRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public AuthorDto save(AuthorDto author) {

        Author authorEntity = modelMapper.map(author, Author.class);
        authorEntity = authorRepository.save(authorEntity);

        author.setAuthorId(authorEntity.getAuthorId());
        return author;
    }

    @Override
    public AuthorDto getById(Long id) {
        Author author = authorRepository.getOne(id);
        return modelMapper.map(author, AuthorDto.class);
    }

    @Override
    public List<AuthorDto> getAll() {
        List<Author> data = authorRepository.findAll();
        return Arrays.asList(modelMapper.map(data, AuthorDto[].class));
    }

    @Override
    public TPage<AuthorDto> getAllPageable(Pageable pageable) {
        Page<Author> data = authorRepository.findAll(pageable);
        TPage<AuthorDto> respnose = new TPage<AuthorDto>();
        respnose.setStat(data, Arrays.asList(modelMapper.map(data.getContent(), AuthorDto[].class)));
        return respnose;
    }

    @Override
    public Boolean delete(Long id) {
        authorRepository.deleteById(id);
        return true;
    }

    @Override
    public AuthorDto update(Long id, AuthorDto author) {
        Author authorDb = authorRepository.getOne(id);
        authorDb.setAuthorId(author.getAuthorId());
        authorDb.setUname(author.getUname());
        authorDb.setName(author.getName());
        authorDb.setRole(author.getRole());

        authorRepository.save(authorDb);
        return modelMapper.map(authorDb, AuthorDto.class);
    }
}
