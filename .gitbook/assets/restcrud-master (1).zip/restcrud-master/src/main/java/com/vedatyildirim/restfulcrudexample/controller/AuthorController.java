package com.vedatyildirim.restfulcrudexample.controller;

import com.vedatyildirim.restfulcrudexample.dto.AuthorDto;
import com.vedatyildirim.restfulcrudexample.service.impl.AuthorServiceImpl;
import com.vedatyildirim.restfulcrudexample.util.TPage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.lang.Long;


@Api(value = "/author", description = "Author APIs")
@CrossOrigin(origins = "*")
@RequestMapping("/author")
@RestController
public class AuthorController {


    @Autowired
    private final AuthorServiceImpl authorServiceImpl;

    public AuthorController(AuthorServiceImpl authorServiceImpl) {
        this.authorServiceImpl = authorServiceImpl;
    }


    @GetMapping("/pagination")
    @ApiOperation(value = "Get By Pagination Operation", response = AuthorDto.class)
    public ResponseEntity<TPage<AuthorDto>> getAllByPagination(Pageable pageable) {
        TPage<AuthorDto> data = authorServiceImpl.getAllPageable(pageable);
        return ResponseEntity.ok(data);
    }

    @GetMapping("/")
    @ApiOperation(value = "Get All Operation", response = AuthorDto.class, responseContainer = "List")
    public ResponseEntity<List<AuthorDto>> getAll() {
        List<AuthorDto> data = authorServiceImpl.getAll();
        return ResponseEntity.ok(data);
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get By Id Operation", response = AuthorDto.class)
    public ResponseEntity<AuthorDto> getById(@PathVariable(value = "id", required = true) Long id) {
        AuthorDto authorDto = authorServiceImpl.getById(id);
        return ResponseEntity.ok(authorDto);
    }

    @PostMapping
    @ApiOperation(value = "Create Operation", response = AuthorDto.class)
    public ResponseEntity<AuthorDto> create(@Valid @RequestBody AuthorDto author) {
        return ResponseEntity.ok(authorServiceImpl.save(author));
    }

    @PutMapping("/{id}")
    @ApiOperation(value = "Update Operation", response = AuthorDto.class)
    public ResponseEntity<AuthorDto> update(@PathVariable(value = "id", required = true) Long id, @Valid @RequestBody AuthorDto author) {
        return ResponseEntity.ok(authorServiceImpl.update(id, author));
    }

    @DeleteMapping("/{id}")
    @ApiOperation(value = "Delete Operation", response = Boolean.class)
    public ResponseEntity<Boolean> delete(@PathVariable(value = "id", required = true) Long id) {
        return ResponseEntity.ok(authorServiceImpl.delete(id));
    }
}