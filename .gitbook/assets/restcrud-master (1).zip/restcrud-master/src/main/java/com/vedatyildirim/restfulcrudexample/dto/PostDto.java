package com.vedatyildirim.restfulcrudexample.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Post Data Transfer Object")
public class PostDto {
    @ApiModelProperty(required = true,value = "ID")
    private Long postId;
    @ApiModelProperty(required = true,value = "Title")
    private String title;
    @ApiModelProperty(required = true,value = "Body")
    private String body;
    @ApiModelProperty(required = true,value = "Author")
    private AuthorDto author;


}
