# restcrud

Spring Boot REST API CRUD Example