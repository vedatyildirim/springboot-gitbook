package com.vedatyildirim.restfulcrudexample.service.impl;

import com.vedatyildirim.restfulcrudexample.domain.Post;
import com.vedatyildirim.restfulcrudexample.dto.PostDto;
import com.vedatyildirim.restfulcrudexample.enums.Status;
import com.vedatyildirim.restfulcrudexample.repository.AuthorRepository;
import com.vedatyildirim.restfulcrudexample.repository.PostRepository;
import com.vedatyildirim.restfulcrudexample.util.TPage;
import com.vedatyildirim.restfulcrudexample.service.PostService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.List;

@Service
@Transactional
public class PostServiceImpl implements PostService {

    @Autowired
    private final PostRepository postRepository;

    // For Author Relationship
    @Autowired
    private final AuthorRepository authorRepository;

    @Autowired
    private final ModelMapper modelMapper;

    public PostServiceImpl(PostRepository postRepository, AuthorRepository authorRepository, ModelMapper modelMapper) {
        this.postRepository = postRepository;
        this.authorRepository = authorRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public PostDto save(PostDto post) {

        post.setStatus(Status.PUBLISHED);

        Post postEntity = modelMapper.map(post, Post.class);
        postEntity = postRepository.save(postEntity);

        post.setPostId(postEntity.getPostId());
        return post;
    }

    @Override
    public PostDto getById(Long id) {
        Post post = postRepository.getOne(id);
        return modelMapper.map(post, PostDto.class);
    }

    @Override
    public TPage<PostDto> getAllPageable(Pageable pageable) {
        Page<Post> data = postRepository.findAll(pageable);
        TPage<PostDto> respnose = new TPage<PostDto>();
        respnose.setStat(data, Arrays.asList(modelMapper.map(data.getContent(), PostDto[].class)));
        return respnose;
    }

    public List<PostDto> getAll() {
        List<Post> data = postRepository.findAll();
        return Arrays.asList(modelMapper.map(data, PostDto[].class));
    }

    @Override
    public Boolean delete(Long id) {
        postRepository.deleteById(id);
        return true;
    }

    @Override
    public PostDto update(Long id, PostDto post) {
        Post postDb = postRepository.getOne(id);
        postDb.setPostId(post.getPostId());
        postDb.setTitle(post.getTitle());
        postDb.setBody(post.getBody());
        postDb.setSattus(post.getStatus());
        postRepository.save(postDb);
        return modelMapper.map(postDb, PostDto.class);
    }


}
