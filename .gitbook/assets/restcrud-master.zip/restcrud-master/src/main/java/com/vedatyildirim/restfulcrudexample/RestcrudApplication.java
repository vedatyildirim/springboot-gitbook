package com.vedatyildirim.restfulcrudexample;

import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import org.springframework.core.env.SimpleCommandLinePropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.repository.init.Jackson2RepositoryPopulatorFactoryBean;
import org.springframework.core.io.Resource;
import org.springframework.core.env.Environment;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Slf4j
@SpringBootApplication
public class RestcrudApplication {

    //public static void main(String[] args) { SpringApplication.run(RestcrudApplication.class, args); }
    public static void main(String[] args) throws UnknownHostException {

        SpringApplication app = new SpringApplication(RestcrudApplication.class);
        app.setBannerMode(Banner.Mode.OFF);
        SimpleCommandLinePropertySource source = new SimpleCommandLinePropertySource(args);

        //addDefaultProfile(app, source);
        Environment env = app.run(args).getEnvironment();
        String author = "Vedat Yıldırım";
        String version = "v1.0.1";
        String h2 = "http://localhost:8092/db";
        log.info("Access URLs:\n----------------------------------------------------------\n\t" +
                        "App Local: \t\thttp://127.0.0.1:{}\n\t" +
                        "App External: \thttp://{}:{}\n----------------------------------------------------------\n\t" +
                        "DB Local: \t\thttp://127.0.0.1:{}/db\n\t"+
                        "DB External: \thttp://127.0.0.1:{}/db\n----------------------------------------------------------",
                // App Local: Server Port Param.
                env.getProperty("server.port"),

                // App Local: Host and Port Param.
                InetAddress.getLocalHost().getHostAddress(),
                env.getProperty("server.port"),

                // Database Local: Server Port
                env.getProperty("server.port"),

                // DB External: Host and Port Param.
                InetAddress.getLocalHost().getHostAddress(),
                env.getProperty("server.port"));

    }

    @Bean
    public ModelMapper getModelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        return modelMapper;
    }

    @Bean
    public Jackson2RepositoryPopulatorFactoryBean repositoryPopulator() {
        Jackson2RepositoryPopulatorFactoryBean factory = new Jackson2RepositoryPopulatorFactoryBean();
        factory.setResources(new Resource[]{new ClassPathResource("import_data.json")});
        return factory;
    }

}
