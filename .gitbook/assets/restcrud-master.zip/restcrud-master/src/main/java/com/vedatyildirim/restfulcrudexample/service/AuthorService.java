package com.vedatyildirim.restfulcrudexample.service;

import com.vedatyildirim.restfulcrudexample.dto.AuthorDto;
import com.vedatyildirim.restfulcrudexample.util.TPage;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AuthorService {

    AuthorDto save(AuthorDto author);

    AuthorDto getById(Long authorId);

    List<AuthorDto> getAll();

    TPage<AuthorDto> getAllPageable(Pageable pageable);

    Boolean delete(Long author);

    AuthorDto update(Long authorId, AuthorDto author);
}
