package com.vedatyildirim.restfulcrudexample.enums;

public enum Status {
    DELETED,
    PUBLISHED,
    TEMPLATE
}
